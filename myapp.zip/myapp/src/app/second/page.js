export const dynamic = "force-dynamic";
export const dynamicParams = true;
export const revalidate = 0;
export const fetchCache = "force-no-store";

import Link from "next/link";
import React from "react";

async function Second() {
  const res = await fetch(
    "https://jsonplaceholder.typicode.com/posts?userId=10",
    { cache: "no-store" }
  );
  const data = await res.json();
  console.log(data);
  return (
    <div>
      <Link href={"/"}>first</Link>
      Second
    </div>
  );
}

export default Second;
